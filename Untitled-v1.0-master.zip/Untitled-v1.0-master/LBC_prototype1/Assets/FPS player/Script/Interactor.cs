﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Interactor : MonoBehaviour {


    public Camera camera;
    public float ray_Range;
    public GameObject interact;
    public KeyCode key;

    public GameObject inventorypanel;
    public GameObject menupanel;
    public KeyCode inventory;
    public KeyCode menu;

    public Image Image1;
    public Image Image2;
    public Image Image3;
    public Image Image4;
    public Image Image5;
    public Image Image6;
    public Image Image7;

    int inum1;
    int inum2;
    int inum3;
    int inum4;
    int inum5;
    int inum6;
    int inum7;

    public Sprite sprite1;
    public Sprite sprite2;
    public Sprite sprite3;
    public Sprite sprite4;
    public Sprite sprite5;
    public Sprite sprite6;
    public Sprite sprite7;

    private bool isshow = false;
    private bool menushow = false;

    void Start () {

        
    }
	
	void inter()
    {
        interact.SetActive(true);
    }

    void showinventory()
    {
        inventorypanel.SetActive(isshow);

    }
    void showmenu()
    {
        menupanel.SetActive(menushow);
    }

  


    void Update () {

        if (Input.GetKeyDown(inventory))
        {
            isshow = !isshow;

            showinventory();
        }

        if (Input.GetKeyDown(menu))
        {
            menushow = !menushow;

            showmenu();

        }

        interact.SetActive(false);
        Ray ray_Cast = camera.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
        RaycastHit ray_Hit;

        if (Physics.Raycast(ray_Cast, out ray_Hit, ray_Range))
        {
                 
            if (ray_Hit.collider.tag == "sphere")
            {
                Debug.Log("hello sphere");
                inter();

                if (Input.GetKeyDown(key))
                {
                    Destroy(ray_Hit.collider.gameObject);

                    if ( inum1 == 0)
                    {
                        Image1.GetComponent<Image>().sprite = sprite1;
                        inum1 = 1;
                    }
                    else
                    if (inum2 == 0)
                    {
                        Image2.GetComponent<Image>().sprite = sprite1;
                        inum2 = 1;
                    }
                    else
                    if (inum3 == 0)
                    {
                        Image3.GetComponent<Image>().sprite = sprite1;
                        inum3 = 1;
                    }
                    else
                    if (inum4 == 0)
                    {
                        Image4.GetComponent<Image>().sprite = sprite1;
                        inum4 = 1;
                    }
                    else
                    if (inum5 == 0)
                    {
                        Image5.GetComponent<Image>().sprite = sprite1;
                        inum5 = 1;
                    }
                    else
                    if (inum6 == 0)
                    {
                        Image6.GetComponent<Image>().sprite = sprite1;
                        inum6 = 1;
                    }
                    else
                    if (inum7 == 0)
                    {
                        Image7.GetComponent<Image>().sprite = sprite1;
                        inum7 = 1;
                    }


                }
            }
        }
	}
}
